﻿Imports System.Drawing.Text
Imports Newtonsoft.Json.Linq
Imports System.Net.Http
Imports System.Security.Policy

Public Class View_Submissions
    Private ReadOnly _submission As Submission
    Public Sub New(ByVal submission As Submission)
        InitializeComponent()
        _submission = submission
    End Sub

    Private Sub View_Submission_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        ' Display submission details in textboxes
        If _submission IsNot Nothing Then
            TextBox1.Text = _submission.Name
            TextBox4.Text = _submission.Email
            TextBox3.Text = _submission.Phone
            TextBox2.Text = _submission.GitHubLink
            TextBox5.Text = _submission.StopwatchTime
        End If
    End Sub

    Private Sub Button1_KeyDown(sender As Object, e As KeyEventArgs) Handles Button1.KeyDown
        If e.Control AndAlso e.KeyCode = Keys.P Then
            Button1.PerformClick()
        End If
    End Sub

    Private Sub Button2_KeyDown(sender As Object, e As KeyEventArgs) Handles Button2.KeyDown
        If e.Control AndAlso e.KeyCode = Keys.F Then
            Button2.PerformClick()
        End If
    End Sub
End Class

Public Class Submission
    Public Property Name As String
    Public Property Email As String
    Public Property Phone As String
    Public Property GitHubLink As String
    Public Property StopwatchTime As String

    ' Constructor for initializing properties
    Public Sub New(ByVal Name As String, ByVal Email As String, ByVal Phone As String, ByVal GitHubLink As String, ByVal StopwatchTime As String)
        Me.Name = Name
        Me.Email = Email
        Me.Phone = Phone
        Me.GitHubLink = GitHubLink
        Me.StopwatchTime = StopwatchTime
    End Sub
End Class