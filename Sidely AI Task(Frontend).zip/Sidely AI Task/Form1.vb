﻿Imports System.Net.Http
Imports Newtonsoft.Json
Imports System.Threading.Tasks
Imports System.Windows.Forms.VisualStyles.VisualStyleElement

Public Class Slidely_Form_App
    Inherits System.Windows.Forms.Form
    Private currentIndex As Integer = 0

    Private Async Sub Form1_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        Dim processInfo As New ProcessStartInfo()
        processInfo.FileName = "node"
        processInfo.Arguments = "index.js"
        processInfo.WorkingDirectory = "C:\Users\Lenovo\source\repos\Slidely Task ExpressApp1\Slidely Task ExpressApp1\dist" ' Replace with your actual path
        processInfo.CreateNoWindow = True
        processInfo.UseShellExecute = False

        Dim process As New Process()
        process.StartInfo = processInfo

        Try
            process.Start()
            'MessageBox.Show("Node.js server started successfully.", "Server Started", MessageBoxButtons.OK, MessageBoxIcon.Information)
        Catch ex As Exception
            MessageBox.Show($"Error starting Node.js server: {ex.Message}", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error)
        End Try

    End Sub

    Private Sub Button2_Click(sender As Object, e As EventArgs) Handles Button2.Click
        Dim ThirdForm As New Create_Submission
        ThirdForm.Show()
        Me.Hide()
    End Sub

    Private Async Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click

        Dim client As New HttpClient()
        Dim url As String = "http://localhost:3000/read?index=0"

        Try
            Dim response = Await client.GetAsync(url)

            ' Handle response
            If response.IsSuccessStatusCode Then
                Dim json As String = Await response.Content.ReadAsStringAsync()

                ' Deserialize single submission object
                Dim submission As Submission = JsonConvert.DeserializeObject(Of Submission)(json)

                ' Open a new form to display submission details
                Dim SecondForm As New View_Submissions(submission)
                SecondForm.Show()
            Else
                MessageBox.Show("Error retrieving submissions: " & response.ReasonPhrase, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error)
            End If
        Catch ex As Exception
            MessageBox.Show("Error retrieving submissions: " & ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error)
        End Try
    End Sub


    Private Sub Button1_KeyDown(sender As Object, e As KeyEventArgs) Handles Button1.KeyDown
        If e.Control AndAlso e.KeyCode = Keys.V Then
            Button1.PerformClick()
        End If
    End Sub

    Private Sub Button2_KeyDown(sender As Object, e As KeyEventArgs) Handles Button2.KeyDown
        If e.Control AndAlso e.KeyCode = Keys.N Then
            Button2.PerformClick()
        End If
    End Sub
End Class
