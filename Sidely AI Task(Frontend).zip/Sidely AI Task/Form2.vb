﻿Imports System.Net.Http
Imports System.Threading.Tasks

Public Class Create_Submission

    Dim isRunning As Boolean = True
    Dim elapsedTime As Integer = 0

    Private Sub Form2_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        Timer1.Interval = 1000
        Timer1.Start()
    End Sub

    Private Sub Timer1_Tick(sender As Object, e As EventArgs) Handles Timer1.Tick
        elapsedTime += 1
        Timer1.Interval = 1000
        Dim ts As TimeSpan = TimeSpan.FromSeconds(elapsedTime)
        Label6.Text = String.Format("{0:00}:{1:00}:{2:00}", ts.Hours, ts.Minutes, ts.Seconds)
    End Sub

    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        If isRunning Then
            Timer1.Stop()
        Else
            Timer1.Start()
        End If
        isRunning = Not isRunning

    End Sub

    Private Sub Button1_KeyDown(sender As Object, e As KeyEventArgs) Handles Button1.KeyDown
        If e.Control AndAlso e.KeyCode = Keys.T Then
            Button1.PerformClick()
        End If
    End Sub

    Private Sub Button2_KeyDown(sender As Object, e As KeyEventArgs) Handles Button2.KeyDown
        If e.Control AndAlso e.KeyCode = Keys.S Then
            Button2.PerformClick()
        End If
    End Sub

    Private Sub ClearForm()
        TextBox1.Clear()
        TextBox2.Clear()
        TextBox3.Clear()
        TextBox4.Clear()
        Label6.Text = "00:00:00"
    End Sub

    Private Async Sub Button2_Click(sender As Object, e As EventArgs) Handles Button2.Click
        Timer1.Stop()

        Dim name As String = TextBox1.Text
        Dim email As String = TextBox4.Text
        Dim phone As String = TextBox3.Text
        Dim githubLink As String = TextBox2.Text
        Dim stopwatchTime As String = Label6.Text

        Dim client As New HttpClient()
        Dim url As String = "http://localhost:3000/submit"

        ' Prepare data to send in JSON format
        Dim json As String = $"{{ ""name"": ""{name}"", ""email"": ""{email}"", ""phone"": ""{phone}"", ""github_link"": ""{githubLink}"", ""stopwatch_time"": ""{stopwatchTime}"" }}"

        ' Configure headers
        Dim content = New StringContent(json, System.Text.Encoding.UTF8, "application/json")

        Try
            Dim response = Await client.PostAsync(url, content)

            ' Handle response
            Dim responseString = Await response.Content.ReadAsStringAsync()
            Dim result As DialogResult = MessageBox.Show(responseString, "Submission Status", MessageBoxButtons.OK, MessageBoxIcon.Information)
            ClearForm()
            'Dim result As DialogResult = MessageBox.Show("Submission successful!", "Success", MessageBoxButtons.OK, MessageBoxIcon.Information)
            If result = DialogResult.OK Then
                Dim FirstForm As New Slidely_Form_App
                FirstForm.Show()
                Me.Hide()
            End If
        Catch ex As Exception
            MessageBox.Show("Error submitting data: " & ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error)
        End Try
    End Sub
End Class