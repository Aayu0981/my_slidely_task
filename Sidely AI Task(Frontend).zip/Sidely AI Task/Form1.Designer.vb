﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()>
Partial Class Slidely_Form_App
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()>
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()>
    Private Sub InitializeComponent()
        Label1 = New Label()
        Button1 = New Button()
        Button2 = New Button()
        SuspendLayout()
        ' 
        ' Label1
        ' 
        Label1.AutoSize = True
        Label1.BackColor = SystemColors.Control
        Label1.Font = New Font("Times New Roman", 28F)
        Label1.ImageAlign = ContentAlignment.TopCenter
        Label1.Location = New Point(118, 133)
        Label1.Name = "Label1"
        Label1.Size = New Size(945, 53)
        Label1.TabIndex = 0
        Label1.Text = "Ayushi Tomar, Slidely Task 2 - Slidely Form App"
        Label1.TextAlign = ContentAlignment.TopCenter
        ' 
        ' Button1
        ' 
        Button1.BackColor = Color.FromArgb(CByte(255), CByte(255), CByte(128))
        Button1.Font = New Font("Times New Roman", 24F, FontStyle.Regular, GraphicsUnit.Point, CByte(0))
        Button1.Location = New Point(210, 239)
        Button1.Name = "Button1"
        Button1.Size = New Size(751, 79)
        Button1.TabIndex = 1
        Button1.Text = "VIEW SUBMISSIONS (CTRL + V)"
        Button1.UseVisualStyleBackColor = False
        ' 
        ' Button2
        ' 
        Button2.BackColor = Color.FromArgb(CByte(128), CByte(255), CByte(255))
        Button2.Font = New Font("Times New Roman", 24F, FontStyle.Regular, GraphicsUnit.Point, CByte(0))
        Button2.Location = New Point(210, 358)
        Button2.Name = "Button2"
        Button2.Size = New Size(751, 79)
        Button2.TabIndex = 2
        Button2.Text = "CREATE NEW SUBMISSION (CTRL + N)"
        Button2.UseVisualStyleBackColor = False
        ' 
        ' Slidely_Form_App
        ' 
        AutoScaleDimensions = New SizeF(8F, 20F)
        AutoScaleMode = AutoScaleMode.Font
        ClientSize = New Size(1182, 583)
        Controls.Add(Button1)
        Controls.Add(Button2)
        Controls.Add(Label1)
        Name = "Slidely_Form_App"
        StartPosition = FormStartPosition.CenterScreen
        Text = "Form1"
        ResumeLayout(False)
        PerformLayout()
    End Sub

    Friend WithEvents Label1 As Label
    Friend WithEvents Button1 As Button
    Friend WithEvents Button2 As Button

End Class
