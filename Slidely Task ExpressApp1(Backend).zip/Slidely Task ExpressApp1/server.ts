import express, { Request, Response } from 'express';
import bodyParser from 'body-parser';
import fs from 'fs';
import path from 'path';


const app = express();
const PORT = 3000;
const dbFilePath = path.join(__dirname, 'db.json');

// Middleware
app.use(bodyParser.json());

// Ping endpoint
app.get('/ping', (req: Request, res: Response) => {
    res.json(true);
});

// Submit endpoint
app.post('/submit', (req: Request, res: Response) => {
    const { name, email, phone, github_link, stopwatch_time } = req.body;

    // Read existing submissions from db.json
    let submissions: any[] = [];
    try {
        const data = fs.readFileSync(dbFilePath, 'utf8');
        submissions = JSON.parse(data);
    } catch (error) {
        console.error('Error reading db.json:', error);
    }

    // Add new submission
    const newSubmission = { name, email, phone, github_link, stopwatch_time };
    submissions.push(newSubmission);

    // Write updated submissions to db.json
    fs.writeFile(dbFilePath, JSON.stringify(submissions, null, 2), (err) => {
        if (err) {
            console.error('Error writing to db.json:', err);
            res.status(500).json({ message: 'Error saving submission' });
        } else {
            res.json({ message: 'Submission saved successfully' });
        }
    });
});

// Read endpoint
app.get('/read', (req: Request, res: Response) => {
    const index = Number(req.query.index);

    // Read submissions from db.json
    try {
        const data = fs.readFileSync(dbFilePath, 'utf8');
        const submissions = JSON.parse(data);

        if (index >= 0 && index < submissions.length) {
            res.json(submissions[index]);
        } else {
            res.status(404).json({ message: 'Submission not found' });
        }
    } catch (error) {
        console.error('Error reading db.json:', error);
        res.status(500).json({ message: 'Error retrieving submission' });
    }
});

// Start server
app.listen(PORT, () => {
    console.log(`Server is running on http://localhost:${PORT}`);
});
